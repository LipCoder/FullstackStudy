package com.test;

public class MemberDTO
{
   private String name, ssn, ibsadate
           , city, tel, buseo, jikwi ;
   private int basicpay, sudang, pay;
   private int emp_id, city_id, buseo_id, jikwi_id, min_basicpay;
   
   public int getMin_basicpay()
   {
      return min_basicpay;
   }
   public void setMin_basicpay(int min_basicpay)
   {
      this.min_basicpay = min_basicpay;
   }
   public int getCity_id()
   {
      return city_id;
   }
   public void setCity_id(int city_id)
   {
      this.city_id = city_id;
   }
   public int getBuseo_id()
   {
      return buseo_id;
   }
   public void setBuseo_id(int buseo_id)
   {
      this.buseo_id = buseo_id;
   }
   public int getJikwi_id()
   {
      return jikwi_id;
   }
   public void setJikwi_id(int jikwi_id)
   {
      this.jikwi_id = jikwi_id;
   }
   public int getPay()
   {
      return pay;
   }
   public void setPay(int pay)
   {
      this.pay = pay;
   }
   public int getEmp_id()
   {
      return emp_id;
   }
   public void setEmp_id(int emp_id)
   {
      this.emp_id = emp_id;
   }
   public String getName()
   {
      return name;
   }
   public void setName(String name)
   {
      this.name = name;
   }
   public String getSsn()
   {
      return ssn;
   }
   public void setSsn(String ssn)
   {
      this.ssn = ssn;
   }
   public String getIbsadate()
   {
      return ibsadate;
   }
   public void setIbsadate(String ibsadate)
   {
      this.ibsadate = ibsadate;
   }
   public String getCity()
   {
      return city;
   }
   public void setCity(String city)
   {
      this.city = city;
   }
   public String getTel()
   {
      return tel;
   }
   public void setTel(String tel)
   {
      this.tel = tel;
   }
   public String getBuseo()
   {
      return buseo;
   }
   public void setBuseo(String buseo)
   {
      this.buseo = buseo;
   }
   public String getJikwi()
   {
      return jikwi;
   }
   public void setJikwi(String jikwi)
   {
      this.jikwi = jikwi;
   }
   public int getBasicpay()
   {
      return basicpay;
   }
   public void setBasicpay(int basicpay)
   {
      this.basicpay = basicpay;
   }
   public int getSudang()
   {
      return sudang;
   }
   public void setSudang(int sudang)
   {
      this.sudang = sudang;
   }

   
   
}